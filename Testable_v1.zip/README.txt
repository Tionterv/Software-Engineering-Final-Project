1. Install Kivy and all other dependencies required, all libraries and packages used are listed at the top of the .py file.
2. Run the python file directly.
Notes: There are fixed number of locations to put stuff in:
Location1: Aisle-Bay 1-2, capacity: 50
Location2: Aisle-Bay 2-3, capacity: 50
Location3: Aisle-Bay 1-4, capacity: 80
Location4: Aisle-Bay 4-7, capacity: 120
All repositories are set to be empty, so you need to add something into the repository first.
3. There are three things can be tested currently.
	i. Add function: Add a product of certain quantity to certain place.
	ii. Remove function: Remove a product of certain quantity at a certain place
	iii. Search function: Search for a certain product id at a certain place.
	All inputs are supposed to be integers.