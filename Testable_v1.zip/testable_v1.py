from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.image import Image
from kivy.uix.rst import RstDocument
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget
from kivy.core.window import Window
from kivy.uix.label import Label


filename = "input.txt"  # csv file or text file
'''
TabbedPanel
============
Test of the widget TabbedPanel.
'''

from kivy.app import App
from kivy.uix.tabbedpanel import TabbedPanel, TabbedPanelHeader, TabbedPanelItem
from kivy.lang import Builder

'''Builder.load_string("""
<Test>:
    size_hint: .90, .90
    pos_hint: {'center_x': .5, 'center_y': .5}
    do_default_tab: False
    Label:
        text:'Hello WORLD'

    TabbedPanelItem:
        text: 'Home'
        RstDocument:
            text:
                '\\n'.join(("**Welcome to Overhead-CEO**", "-----------",
                "You are in the third tab."))
    TabbedPanelItem:
        text: 'Add'
        BoxLayout:
            Label:
                text: 'Second tab content area'
            Button:
                text: 'Button that does not 	hing'
    TabbedPanelItem:
        text: 'Remove'
        Label:
            text_size: self.size
            valign: "top"
            halign: "left"
            text: "HELLO"
    TabbedPanelItem:
        text: 'Search'
        Label:
            text: 'First tab content area'
    TabbedPanelItem:
        text: 'Inventory'
        Label:
            text: 'First tab content area'
""")'''


# Builder.load_file("temp.kv")

class Location:
    def __init__(self, aisle, bay, capacity):
        self.aisle = aisle
        self.bay = bay
        self.capacity = capacity
        self.available = capacity
        self.categories = 0
        self.item = {}  # to store all

    def add_item(self, ident, quant):
        if quant > self.available:  # cannot add
            return False
        else:
            self.available -= quant
            if ident not in self.item:  # no pre-exist item found
                self.item[ident] = quant
                self.categories += 1
            else:
                self.item[ident] += quant
            return True

    def remove_item(self, ident, quant):
        if ident not in self.item:
            return False
        else:
            if quant > self.item[ident]:
                return False
            else:
                self.item[ident] -= quant
                self.available += quant
                return True

    def search_item(self, ident):
        if ident in self.item:
            return 1
        return -1

    def selfprint(self):
        # print(self.idx, self.capacity, self.available, self.item)
        print(1, 2, 3, 4, 5)


class Test(TabbedPanel):
    def __init__(self, **kwargs):
        super(Test, self).__init__(**kwargs)
        self.size_hint = (0.9, 0.9)
        self.pos_hint = {'center_x': .5, 'center_y': .5}
        self.do_default_tab = False
        tab1 = TabbedPanelItem(text="Home")
        rst_docu = RstDocument(text='\\n'.join(("**Welcome to Overhead-CEO**", "-----------",
                                                "You are in the third tab.")))
        tab1.add_widget(rst_docu)
        wimg = Image(source='Overhead-CEO-Logo4.jpg')  # image background
        tab1.add_widget(wimg)
        self.add_widget(tab1)
        tab2 = TabbedPanelItem(text="Add")
        '''box1 = BoxLayout()
        label1 = Label(text="Second tab content area")
        input1 = TextInput(multiline=False)
        button1 = Button(text="Button that does not 	hing")
        button1.bind(on_press=self.add_press1)
        box1.add_widget(label1)
        box1.add_widget(input1)
        box1.add_widget(button1)
        tab2.add_widget(box1)
        self.add_widget(tab2)'''
        layout1_1 = GridLayout()
        layout1_1.cols = 1
        layout1_2 = GridLayout()
        layout1_2.cols = 2
        layout1_2.add_widget(Label(text="Product ID"))
        self.addid = TextInput(multiline=False)
        layout1_2.add_widget(self.addid)
        layout1_2.add_widget(Label(text="Quantity"))
        self.addquant = TextInput(multiline=False)
        layout1_2.add_widget(self.addquant)
        layout1_2.add_widget(Label(text="Aisle"))
        self.addaisle = TextInput(multiline=False)
        layout1_2.add_widget(self.addaisle)
        layout1_2.add_widget(Label(text="Bay"))
        self.addbay = TextInput(multiline=False)
        layout1_2.add_widget(self.addbay)
        layout1_1.add_widget(layout1_2)
        self.button1 = Button(text="Add")
        self.button1.bind(on_press=self.add_press1)
        layout1_1.add_widget(self.button1)
        layout1_3 = GridLayout()
        layout1_3.cols = 2
        layout1_3.add_widget(Label(text="Log Info"))
        self.addinfo = TextInput(text="")
        layout1_3.add_widget(self.addinfo)
        layout1_1.add_widget(layout1_3)
        tab2.add_widget(layout1_1)
        self.add_widget(tab2)
        tab3 = TabbedPanelItem(text="Remove")
        # label2 = Label(text="HELLO", text_size=self.size, valign="top", halign="left")
        layout2_1 = GridLayout()
        layout2_1.cols = 1
        layout2_2 = GridLayout()
        layout2_2.cols = 2
        layout2_2.add_widget(Label(text="Product ID"))
        self.removeid = TextInput(multiline=False)
        layout2_2.add_widget(self.removeid)
        layout2_2.add_widget(Label(text="Quantity"))
        self.removequant = TextInput(multiline=False)
        layout2_2.add_widget(self.removequant)
        layout2_2.add_widget(Label(text="Aisle"))
        self.removeaisle = TextInput(multiline=False)
        layout2_2.add_widget(self.removeaisle)
        layout2_2.add_widget(Label(text="Bay"))
        self.removebay = TextInput(multiline=False)
        layout2_2.add_widget(self.removebay)
        layout2_1.add_widget(layout2_2)
        self.button2 = Button(text="Remove")
        self.button2.bind(on_press=self.add_press2)
        layout2_1.add_widget(self.button2)
        layout2_3 = GridLayout()
        layout2_3.cols = 2
        layout2_3.add_widget(Label(text="Log Info"))
        self.removeinfo = TextInput(text="")
        layout2_3.add_widget(self.removeinfo)
        layout2_1.add_widget(layout2_3)
        tab3.add_widget(layout2_1)
        self.add_widget(tab3)
        tab4 = TabbedPanelItem(text="Search")
        layout3_1 = GridLayout()
        layout3_1.cols = 1
        layout3_2 = GridLayout()
        layout3_2.cols = 2
        layout3_2.add_widget(Label(text="Product ID"))
        self.searchid = TextInput(multiline=False)
        layout3_2.add_widget(self.searchid)
        layout3_2.add_widget(Label(text="Aisle"))
        self.searchaisle = TextInput(multiline=False)
        layout3_2.add_widget(self.searchaisle)
        layout3_2.add_widget(Label(text="Bay"))
        self.searchbay = TextInput(multiline=False)
        layout3_2.add_widget(self.searchbay)
        layout3_1.add_widget(layout3_2)
        self.button3 = Button(text="Search")
        self.button3.bind(on_press=self.add_press3)
        layout3_1.add_widget(self.button3)
        layout3_3 = GridLayout()
        layout3_3.cols = 2
        layout3_3.add_widget(Label(text="Result"))
        self.searchinfo = TextInput(text="")
        layout3_3.add_widget(self.searchinfo)
        layout3_1.add_widget(layout3_3)
        tab4.add_widget(layout3_1)
        self.add_widget(tab4)
        tab5 = TabbedPanelItem(text="Inventory")
        label4 = Label(text="First tab content area")
        tab5.add_widget(label4)
        self.add_widget(tab5)
        loca1 = Location(1, 2, 50)
        loca2 = Location(2, 3, 50)
        loca3 = Location(1, 4, 80)
        loca4 = Location(4, 7, 120)
        self.loc_list = [loca1, loca2]

    def add_press1(self, instance):
        """print(int(self.addid.text), int(self.addquant.text), int(self.addaisle.text), int(self.addbay.text))
        print("type of input text: {}".format(type(int(self.addid.text))))
        self.addinfo.text = "Success\""""
        addid = int(self.addid.text)
        addquant = int(self.addquant.text)
        addaisle = int(self.addaisle.text)
        addbay = int(self.addbay.text)
        for i in range(len(self.loc_list)):
            if self.loc_list[i].aisle == addaisle and self.loc_list[i].bay == addbay:
                if self.loc_list[i].add_item(addid, addquant):
                    self.addinfo.text = "Success Add {} Product ID: {} to Aisle-Bay {}-{}".format(addquant, addid, addaisle, addbay)
                else:
                    self.addinfo.text = "Space not enough to fill the given quantity"
                return
        self.addinfo.text = "No such location found"

    def add_press2(self, instance):
        """print(int(self.removeid.text), int(self.removequant.text), int(self.removeaisle.text), int(self.removebay.text))
        print("type of input text: {}".format(type(int(self.removeid.text))))
        self.removeinfo.text = "Success\""""
        # pass
        removeid = int(self.removeid.text)
        removequant = int(self.removequant.text)
        removeaisle = int(self.removeaisle.text)
        removebay = int(self.removebay.text)
        for i in range(len(self.loc_list)):
            if self.loc_list[i].aisle == removeaisle and self.loc_list[i].bay == removebay:
                if self.loc_list[i].remove_item(removeid, removequant):
                    self.removeinfo.text = "Success Remove {} Product ID: {} to Aisle-Bay {}-{}".format(removequant, removeid,                                                                                removeaisle, removebay)
                else:
                    self.removeinfo.text = "Failure Remove: remove more than available"
                return
        self.removeinfo.text = "No such location found"

    def add_press3(self, instance):
        """print(int(self.searchid.text), int(self.searchquant.text), int(self.searchaisle.text), int(self.searchbay.text))
        print("type of input text: {}".format(type(int(self.searchid.text))))
        self.searchinfo.text = "Success\""""
        searchid = int(self.searchid.text)
        searchaisle = int(self.searchaisle.text)
        searchbay = int(self.searchbay.text)
        for i in range(len(self.loc_list)):
            if self.loc_list[i].aisle == searchaisle and self.loc_list[i].bay == searchbay:
                print(5555)
                if searchid in self.loc_list[i].item:
                    self.searchinfo.text = "Info found\nProduct ID: {}\nQuantity: {}\nAisle: {}\nBay: {}\n".format(searchid,self.loc_list[i].item[searchid], searchaisle, searchbay)
                else:
                    self.searchinfo.text = "No Product ID: {} found at Aisle: {} Bay: {}".format(searchid, searchaisle, searchbay)
                return
        self.searchinfo.text = "No Location of Aisle: {} Bay: {} found".format(searchaisle, searchbay)


class Overhead_CEO(App):
    def build(self):
        Window.clearcolor = (255 / 255.0, 153 / 255.0, 51 / 255.0, 1)
        # lbl = Label(text = 'Label HERE', pos = )
        return Test()
        return Button(text="Hello World")


class TestApp(App):
    def build(self):
        # Window.clearcolor = (1,1,1,1)
        # return Button(text='Welcome to Overhead-CEO')
        return Image(source='Overhead-CEO-Logo4.jpg')


Overhead_CEO().run()
# TestApp().run()
